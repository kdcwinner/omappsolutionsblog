<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/



Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::get('/about', [App\Http\Controllers\Frontend\FrontendController::class, 'about'])->name('about');
Route::get('/contact', [App\Http\Controllers\Frontend\FrontendController::class, 'contact'])->name('contact');
Route::post('add-contact', [App\Http\Controllers\Frontend\FrontendController::class, 'storeContact']);
Route::post('add-newsletter', [App\Http\Controllers\Frontend\FrontendController::class, 'storeNewletter']);


Route::get('/shares', [App\Http\Controllers\Frontend\FrontendController::class, 'shares']);

Route::get('/',[App\Http\Controllers\Frontend\FrontendController::class,'index']);
Route::get('/learn/{category_slug}',[App\Http\Controllers\Frontend\FrontendController::class,'categoryWisePost']);
Route::get('/learn/{category_slug}/{post_slug}',[App\Http\Controllers\Frontend\FrontendController::class,'postDetail']);


Route::prefix('admin')->middleware(['auth','isAdmin'])->group(function(){
    Route::get('/dashboard',[App\Http\Controllers\Admin\DashboardController::class,'index']);

    /* Users Routes */
    Route::get('users',[App\Http\Controllers\Admin\UserController::class,'index']);
    Route::get('add-user',[App\Http\Controllers\Admin\UserController::class,'create']);
    Route::post('add-user',[App\Http\Controllers\Admin\UserController::class,'store']);
    Route::get('edit-user/{id}',[App\Http\Controllers\Admin\UserController::class,'edit']);
    Route::put('update-user/{id}',[App\Http\Controllers\Admin\UserController::class,'update']);
    Route::get('delete-user/{id}',[App\Http\Controllers\Admin\UserController::class,'distroy']);

    /* Categories Routes */
    Route::get('category',[App\Http\Controllers\Admin\CategoryController::class,'index']);
    Route::get('add-category',[App\Http\Controllers\Admin\CategoryController::class,'create']);
    Route::post('add-category',[App\Http\Controllers\Admin\CategoryController::class,'store']);
    Route::get('edit-category/{id}',[App\Http\Controllers\Admin\CategoryController::class,'edit']);
    Route::put('update-category/{id}',[App\Http\Controllers\Admin\CategoryController::class,'update']);
    Route::get('delete-category/{id}',[App\Http\Controllers\Admin\CategoryController::class,'distroy']);

    /* Posts Routes */
    Route::get('posts',[App\Http\Controllers\Admin\PostController::class,'index']);
    Route::get('add-post',[App\Http\Controllers\Admin\PostController::class,'create']);
    Route::post('add-post',[App\Http\Controllers\Admin\PostController::class,'store']);
    Route::get('edit-post/{id}',[App\Http\Controllers\Admin\PostController::class,'edit']);
    Route::put('update-post/{id}',[App\Http\Controllers\Admin\PostController::class,'update']);
    Route::get('delete-post/{id}',[App\Http\Controllers\Admin\PostController::class,'distroy']);

     /* Pages Routes */
     Route::get('pages',[App\Http\Controllers\Admin\PageController::class,'index']);
     Route::get('add-page',[App\Http\Controllers\Admin\PageController::class,'create']);
     Route::post('add-page',[App\Http\Controllers\Admin\PageController::class,'store']);
     Route::get('edit-page/{id}',[App\Http\Controllers\Admin\PageController::class,'edit']);
     Route::put('update-page/{id}',[App\Http\Controllers\Admin\PageController::class,'update']);
     Route::get('delete-page/{id}',[App\Http\Controllers\Admin\PageController::class,'distroy']);

     /* Contacts Routes  */
    Route::get('contacts',[App\Http\Controllers\Admin\ContactController::class,'index']);
    Route::get('delete-contact/{id}',[App\Http\Controllers\Admin\ContactController::class,'distroy']);

});
