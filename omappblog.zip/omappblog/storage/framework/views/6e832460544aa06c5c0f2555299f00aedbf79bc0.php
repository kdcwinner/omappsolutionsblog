<div class="my-5" id="footer-bg">
    <div class="container">
        <div class="row">
            <div class="col-md-3">
            </div>

            <div class="col-md-3">
                <h4>Quick Links</h4>
                <div class="underline"></div>
            </div>
            <div class="col-md-3">
                <h4>Follow Us On</h4>
                <div class="underline"></div>
                <div><a href="" class="text-black">Facebook</a></div>
                <div><a href="" class="text-black">Instagram</a></div>
                <div><a href="" class="text-black">Tweeter</a></div>
                <div><a href="" class="text-black">LinkedIn</a></div>
            </div>
            <div class="col-md-3">
                <h4>Subscribe to Blog via Email</h4>
                <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="alert alert-danger"><?php echo e($error); ?></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <div id="newsletter_message" class=""></div>
                <form name="newsletterForm" id="newsletterForm" method="POST" action="<?php echo e(url('add-newsletter')); ?>" novalidate="">
                    <?php echo csrf_field(); ?>
                    <div class="input-group">
                        <label>Enter your email address to subscribe to this blog and receive notifications of new posts by email.</label>
                    <br />
                    </div>
                    <div class="input-group">
                        <input type="email" id="newsletter-email" name="email" value="<?php echo e(old('email')); ?>" class="form-control" placeholder="Enter your email" required="required" maxlength="40" data-validation-required-name="Please enter your name." aria-invalid="false">
                        <button type="button" class="btn btn-site" id="btn_newsletter">Subscribe</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

</div>

<div class="py-2">
    <div class="container text-center">
        <div class="mb-0">
            &copy; Copyright at <a href="http://www.omappsolutions.in">Om App Solutions</a>
            All right reserved.
            Design and Developed by Om App Solutions <?php echo e(date('Y')); ?>

        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\omappblog\resources\views/layouts/inc/frontend-footer.blade.php ENDPATH**/ ?>