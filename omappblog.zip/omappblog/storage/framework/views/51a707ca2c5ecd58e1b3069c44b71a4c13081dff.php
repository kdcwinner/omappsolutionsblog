<div class="global-navbar">
  <div class="container">
    <div class="row">
      <div class="col-md-3">
        <a href="<?php echo e(url('/')); ?>"> <img src="<?php echo e(asset('assets/images/omappsolutions.png')); ?>" style="margin-left:-60px;width:250px;height:150px;" alt="Om App Solutions"></a>
      </div>
      <div class="col-md-9 my-auto">
        <nav class="navbar navbar-expand-lg navbar-light float-end  ">
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="true" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ">
              <li class="nav-item ">
                <a class="nav-link" href="<?php echo e(url('/')); ?>">Home</a>
              </li>

              <li class="nav-item ">
                <a class="nav-link" href="<?php echo e(url('/about')); ?>">About</a>
              </li>
              <?php
              $categories = App\Models\Category::Where('status',1)->Where('navebar_status',1)->get();
              ?>
              <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li class="nav-item">
                <a class="nav-link" href="<?php echo e(url('learn/'.$category->slug )); ?>"><?php echo e($category->name); ?></a>
              </li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <li class="nav-item ">
                <a class="nav-link border-none" href="<?php echo e(url('/contact')); ?>">Contact</a>
              </li>
            </ul>
          </div>
        </nav>
      </div>
    </div>
  </div>


</div><?php /**PATH C:\xampp\htdocs\omappblog\resources\views/layouts/inc/frontend-navbar.blade.php ENDPATH**/ ?>