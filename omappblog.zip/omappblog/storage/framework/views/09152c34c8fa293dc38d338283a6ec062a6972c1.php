
<?php $__env->startSection('title','Category Listing'); ?>
<?php $__env->startSection('content'); ?>

<div class="container-fluid px-4"><div class="card">

    <div class="card-header">
        <h4>Category List
        <a href="<?php echo e(url('admin/add-category')); ?>" class="btn btn-primary btn-sm float-end">Add Category</a>
        </h4>
    </div>
    <div class="card-body">
        <?php if(session('message')): ?>
            <div class="alert alert-success"> <?php echo e(session('message')); ?></div>
            <?php endif; ?>

            <table id="records_datatable" class="table table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Status</th>
                        <th>Image</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->id); ?></td>
                        <td><?php echo e($item->name); ?></td>
                        <td> <?php echo e($item->status == 1 ? 'Active' : 'Inactive'); ?> </td>
                        <td><image width="100" height="100" src="<?php echo e(asset('uploads/category/'.$item->image)); ?>" alt="<?php echo e($item->image); ?>" ></td>
                        <td>
                            <a href="<?php echo e(url('admin/edit-category/'.$item->id)); ?>" class="btn btn-primary">Edit </a>
                        </td>
                        <td>
                            <a href="<?php echo e(url('admin/delete-category/'.$item->id)); ?>"  onclick="return confirm('Are you sure you want to delete this item?');" class="btn btn-danger">Delete </a>
                        </td>
                        
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
    </div>
</div>
                        
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\omappblog\resources\views/admin/category/index.blade.php ENDPATH**/ ?>