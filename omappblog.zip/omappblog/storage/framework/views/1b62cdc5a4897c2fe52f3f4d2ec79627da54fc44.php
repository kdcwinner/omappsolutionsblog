<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('assets/images/favicon.ico')); ?>">

    <meta name="description" content="<?php echo $__env->yieldContent('meta_description'); ?>" />
    <meta name="keywords" content="<?php echo $__env->yieldContent('meta_keyword'); ?>" />

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    
    <link href="<?php echo e(asset('assets/css/admin/styles.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/admin/custom.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(asset('assets/css/admin/owl.carousel.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/admin/owl.theme.default.css')); ?>" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>

</head>
<body>
    <div id="app">
        <?php echo $__env->make('layouts.inc.frontend-navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <main >
            <?php echo $__env->yieldContent('content'); ?>
        </main>
        <?php echo $__env->make('layouts.inc.frontend-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <script src="<?php echo e(asset('assets/js/admin/jquery-3.6.0.min.js')); ?>" ></script>
    <script src="<?php echo e(asset('assets/js/admin/bootstrap.bundle.min.js')); ?>" ></script>
    <script src="<?php echo e(asset('assets/js/owl.carousel.min.js')); ?>"></script>
    <script>
        $(".category-carousel").owlCarousel();
        // $(".category-carousel").owlCarousel({
        //     loop:true,
        //     margin:10,
        //     nav:true,
        //     dots:false,
        //     responsive:{
        //         0:{
        //             item:1
        //         },
        //         600:{
        //             item:3
        //         },
        //         1000:{
        //             item:5
        //         },
        //     }
        // });
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $("#btn_newsletter").on('click',function(e){
            //e.preventDefault();
            if($("#newsletter-email").val() == ''){
                $("#newsletter_message").addClass('alert alert-danger');
                        $("#newsletter_message").html('Please enter email');
                        setTimeout( function(){
                            $('#newsletter-email').val('');
                            $("#newsletter_message").removeClass('alert alert-danger'); 
                            $("#newsletter_message").html('');
                        },2000);
                        return false;
            }else{
                var validRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
                if ($("#newsletter-email").val().match(validRegex)) {
                    $.ajax({
                        url : "<?php echo e(url('add-newsletter')); ?>",
                        data : {'email' : $("#newsletter-email").val()},
                        type : 'POST',        
                        success : function(result){
                            if(result.status == 'success'){
                                $("#newsletter_message").addClass('alert alert-success');
                                $("#newsletter_message").html(result.message);
                                setTimeout( function(){
                                    $('#newsletter-email').val('');
                                    $("#newsletter_message").removeClass('alert alert-success'); 
                                    $("#newsletter_message").html('');
                                }
                                    ,2000);
                            }else if(result.status == 'already'){
                                $("#newsletter_message").addClass('alert alert-danger');
                                $("#newsletter_message").html(result.message);
                                setTimeout( function(){
                                    $('#newsletter-email').val('');
                                    $("#newsletter_message").removeClass('alert alert-danger'); 
                                    $("#newsletter_message").html('');
                                },2000);
                            }
                            return true;
                        }
                    });
                }else{
                    $("#newsletter_message").addClass('alert alert-danger');
                        $("#newsletter_message").html('Please enter valid email');
                        setTimeout( function(){
                            $('#newsletter-email').val('');
                            $("#newsletter_message").removeClass('alert alert-danger'); 
                            $("#newsletter_message").html('');
                        },2000);
                        return false;
                }
            }
        });
        
    </script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\omappblog\resources\views/layouts/app.blade.php ENDPATH**/ ?>