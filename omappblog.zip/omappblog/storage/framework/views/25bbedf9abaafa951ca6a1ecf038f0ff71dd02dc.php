
<?php $__env->startSection('title','Create User'); ?>
<?php $__env->startSection('content'); ?>

<div class="container-fluid px-4">
                        <div class="card mt-4">
                            <div class="card-header">
                            <h4 class="">Users</h4>
                            <a href="<?php echo e(url('admin/users')); ?>" class="btn btn-danger float-end">Back</a>
                            </div>
                            <div class="card-body">
                                <?php if($errors->any()): ?>
                                <div class="alert alert-dangour">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="alert alert-danger"><?php echo e($error); ?></div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <?php endif; ?>
                                <form action="<?php echo e(url('admin/update-user/'.$user->id)); ?>" method="POST" enctype="multipart/form-data">

                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="mb-3">
                                        <label for="">Role:</label>
                                       <select name="role_as" class="form-control">                                                
                                                        <option value="1" <?php echo e($user->role_as == 1 ? 'selected' : ''); ?>>Admin</option>
                                                        <option value="0" <?php echo e($user->role_as == 0 ? 'selected' : ''); ?>>User</option>                                                
                                        </select>
                                </div>
                                <div class="mb-3">
                                        <label for="">Name:</label>
                                        <input type="text" name="name" value="<?php echo e($user->name); ?>" class="form-control">
                                </div>
                                <div class="mb-3">
                                        <label for="">Title:</label>
                                        <input type="text" name="email"  value="<?php echo e($user->email); ?>" class="form-control">
                                </div>
                                
                                                                
                                <div class="row">                                    
                                    <div class="col-md-9">
                                        <button type="submit" class="btn btn-primary">Update</button>
                                    </div>
                                </div>
</form>
                                
                            </div>

                        </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\omappblog\resources\views/admin/user/edit.blade.php ENDPATH**/ ?>