
<?php $__env->startSection('title',"Om App Solutions"); ?>
<?php $__env->startSection('meta_description',"Om App Solutions is one of the best web development company in India"); ?>
<?php $__env->startSection('meta_keyword',"Om App Solutions, Web Application Development, Mobile Application Development"); ?>


<?php $__env->startSection('content'); ?>
<div class="bg-danger my-5" style="display:none">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="owl-carousel category-carousel owl-theme">
                    <?php $__currentLoopData = $all_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item">
                        <a class="text-decoration-none" href="<?php echo e(url('learn/'.$item->slug)); ?>">
                            <div class="card">
                                <img src="<?php echo e(asset('uploads/category/'.$item->image)); ?>" alt="<?php echo e($item->name); ?>">
                                <div class="card-body text-center">
                                    <h5><?php echo e($item->name); ?></h5>
                                </div>
                            </div>
                        </a>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="bg-gray">
    <div class="container">
        <div class="border text-center p-3">
            <h3>Advertising</h3>
        </div>
    </div>
</div>


<div class=" my-5">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="underline"></div>
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishi</p>
            </div>
        </div>
    </div>
</div>

<div class="my-5">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2>All Categories</h2>
                <div class="underline"></div>
            </div>
            <?php $__currentLoopData = $all_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3">
                <div class=" category-line-box shadow mb-3">
                <a class="va-top text-decoration-none" href="<?php echo e(url('learn/'.$item->slug)); ?>"><img src="<?php echo e(asset('uploads/category/'.$item->image)); ?>" width="100" height="70" ></a>

                    <a href="<?php echo e(url('learn/'.$item->slug)); ?>"> <?php echo e($item->name); ?></a>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>

<div class="my-5">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2>Latest Post</h2>
                <div class="underline"></div>
            </div>
            
                    <?php $__currentLoopData = $latest_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3">
                    <div class=" post-line-box shadow mb-3">
                     <a class="text-decoration-none" href="<?php echo e(url('learn/'.$item->category->slug.'/'.$item->slug)); ?>"><img src="<?php echo e(asset('uploads/post/'.$item->image)); ?>" width="100" height="70" ></a>
                        <a href="<?php echo e(url('learn/'.$item->category->slug.'/'.$item->slug)); ?>" class="va-top"> <?php echo e($item->name); ?></a>
                        <br /><span class="post-time">Posted On: <?php echo e($item->created_at->format('d-m-Y')); ?>, Created By: <?php echo e($item->user->name); ?></span>
                    </div>
                    
                    </div>
                    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             
            </div>
        </div>
    </div>
</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\omappblog\resources\views/frontend/index.blade.php ENDPATH**/ ?>