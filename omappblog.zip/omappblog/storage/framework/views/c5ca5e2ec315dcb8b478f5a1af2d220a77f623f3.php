
<?php $__env->startSection('title',"$post->meta_title"); ?>
<?php $__env->startSection('meta_description',"$post->meta_description"); ?>
<?php $__env->startSection('meta_keyword',"$post->meta_keyword"); ?>
<?php $__env->startSection('content'); ?>
        <div class="container">
            <div class="row">
                <div class="col-md-9 post-data">                                      
                    
                                                                       
                             <h2 class="post-heading"><?php echo $post->name; ?> <label class=" float-end"><?php echo $shareButtons; ?></label></h2>
                        <div class="underline"></div>
                        <img src="<?php echo e(asset('uploads/post/'.$post->image)); ?>" class="post-img" >

                        <div class="post-body">
                                <?php echo $post->description; ?>

                        </div>
                    
                </div>
                <div class="right_part_separater col-md-3">
                    <div class="card">
                            <div class="sidebar-block-title">
                                <h4 class="widget-title">Categories</h4>
                            </div>
                            <div class="mt-4">
                            <?php $__currentLoopData = $all_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="category-box"> 
                            <a class="text-decoration-none" href="<?php echo e(url('learn/'.$item->slug)); ?>"><?php echo e($item->name); ?> (<?php echo e($item->posts_count); ?>)</a></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                    </div>
                    <div class="card">
                            <div class="sidebar-block-title">
                                <h4  class="widget-title">Latest Posts</h4>
                            </div>
                            <ul class="mt-4">
                            <?php $__currentLoopData = $latest_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>                               
                                <a class="text-decoration-none" href="<?php echo e(url('learn/'.$item->category->slug.'/'.$item->slug)); ?>"><img src="<?php echo e(asset('uploads/post/'.$item->image)); ?>" width="100" height="70" ></a>
                                <a class="sidebar-post-title  text-decoration-none" href="<?php echo e(url('learn/'.$item->category->slug.'/'.$item->slug)); ?>"><?php echo e($item->name); ?> <span class="post-time">Posted On: <?php echo e($item->created_at->format('d-m-Y')); ?>, Created By: <?php echo e($item->user->name); ?></span></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                    </div>
                    <?php if(!empty($related_posts)): ?>
                    <div class="card">
                            <div class="sidebar-block-title">
                                <h4  class="widget-title">Related Posts</h4>
                            </div>
                            <ul class="mt-4">
                            <?php $__currentLoopData = $related_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a class="text-decoration-none" href="<?php echo e(url('learn/'.$item->category->slug.'/'.$item->slug)); ?>"><img src="<?php echo e(asset('uploads/post/'.$item->image)); ?>" width="100" height="70" ></a> 
                                <a class="sidebar-post-title text-decoration-none" href="<?php echo e(url('learn/'.$item->category->slug.'/'.$item->slug)); ?>"><?php echo e($item->name); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\omappblog\resources\views/frontend/post/details.blade.php ENDPATH**/ ?>