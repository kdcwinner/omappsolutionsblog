
<?php $__env->startSection('title',"Om App Solutions"); ?>
<?php $__env->startSection('meta_description',"Om App Solutions is one of the best web development company in India"); ?>
<?php $__env->startSection('meta_keyword',"Om App Solutions, Web Application Development, Mobile Application Development"); ?>
<?php $__env->startSection('content'); ?>
<div class=" my-5" >
    <div class="container">
        <div class="row">
                <div class="col-md-12">
                    <h1>Contact Us</h1>
                    <div class="underline"></div>
                    <div class="col-md-8">
                    <?php if($errors->any()): ?>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="alert alert-danger"><?php echo e($error); ?></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <?php if(session('message')): ?>
            <div class="alert alert-success"> <?php echo e(session('message')); ?></div>
            <?php endif; ?>
                    <h3>Leave me a message</h3>
                    <form name="sentMessage" id="contactForm" method="POST" action="<?php echo e(url('add-contact')); ?>" novalidate="">
                       
                    <?php echo csrf_field(); ?>
                    <div class="col-md-4">
                            <div class="form-group">
                            <input type="text" id="name" name="name" value="<?php echo e(old('name')); ?>" class="form-control" placeholder="Name" required="required" maxlength="40" data-validation-required-name="Please enter your name." aria-invalid="false">
                            <p class="help-block text-danger"></p></div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                            <input type="email" id="email" name="email" value="<?php echo e(old('email')); ?>" class="form-control" placeholder="Email" required="required" maxlength="40" data-validation-required-message="Please enter your email address.">
                            <p class="help-block text-danger"></p></div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                            <input type="text" id="contact" name="contact" value="<?php echo e(old('contact')); ?>" class="form-control" placeholder="Contact Number" maxlength="10"  required="required" data-validation-required-message="Please enter your contact number.">
                            <p class="help-block text-danger"></p></div>
                        </div>
                        </div>
                        <div class="form-group">
                        <textarea name="message" id="message" class="form-control" rows="8" placeholder="Message" required="" data-validation-required-message="Please enter message."><?php echo e(old('message')); ?></textarea>
                        <p class="help-block text-danger"></p></div>
                        <div id="success"></div>
                        <button type="submit" class="btn btn-site">Send Message</button>
                    </form>                    
                    </div>
                </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\omappblog\resources\views/frontend/contact.blade.php ENDPATH**/ ?>