
<?php $__env->startSection('title','Contact Listing'); ?>
<?php $__env->startSection('content'); ?>

<div class="container-fluid px-4"><div class="card">

    <div class="card-header">
        <h4>Contact List</h4>
    </div>
    <div class="card-body">
        <?php if(session('message')): ?>
            <div class="alert alert-success"> <?php echo e(session('message')); ?></div>
            <?php endif; ?>

            <table id="records_datatable" class="table table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Contact</th>
                        <th>Message</th>
                        <th>Delete</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->id); ?></td>
                        <td><?php echo e($item->name); ?></td>
                        <td> <?php echo e($item->email); ?> </td>   
                        <td> <?php echo e($item->contact); ?> </td>       
                        <td> <?php echo $item->message; ?> </td>
                        <td>
                            <a href="<?php echo e(url('admin/delete-contact/'.$item->id)); ?>"  onclick="return confirm('Are you sure you want to delete this item?');" class="btn btn-danger">Delete </a>
                        </td>                        
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
    </div>
</div>
                        
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\omappblog\resources\views/admin/contact/index.blade.php ENDPATH**/ ?>