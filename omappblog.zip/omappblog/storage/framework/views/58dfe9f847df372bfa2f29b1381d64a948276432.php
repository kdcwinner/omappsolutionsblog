
<?php $__env->startSection('title','User Listing'); ?>
<?php $__env->startSection('content'); ?>

<div class="container-fluid px-4"><div class="card">

    <div class="card-header">
        <h4>User List
        <a href="<?php echo e(url('admin/add-user')); ?>" class="btn btn-primary btn-sm float-end">Add User</a>
        </h4>
    </div>
    <div class="card-body">
        <?php if(session('message')): ?>
            <div class="alert alert-success"> <?php echo e(session('message')); ?></div>
            <?php endif; ?>

            <table  id="records_datatable" class="table table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->id); ?></td>
                        <td><?php echo e($item->name); ?></td>
                        <td><?php echo e($item->email); ?></td>
                        <td> <?php echo e($item->role_as == 1 ? 'Admin' : 'User'); ?> </td>                        
                        <td>
                            <a href="<?php echo e($item->role_as == 1 ?'#': url('admin/edit-user/'.$item->id)); ?>" class="btn btn-primary">Edit </a>
                        </td>
                        <td>
                            <a href="<?php echo e($item->role_as == 1 ?'#' : url('admin/delete-user/'.$item->id)); ?>"  onclick="return confirm('Are you sure you want to delete this item?');" class="btn btn-danger">Delete </a>
                        </td>                        
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
    </div>
</div>
                        
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\omappblog\resources\views/admin/user/index.blade.php ENDPATH**/ ?>