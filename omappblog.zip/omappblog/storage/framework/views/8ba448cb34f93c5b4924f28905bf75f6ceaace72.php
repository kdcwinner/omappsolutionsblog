
<?php $__env->startSection('title',"$category->meta_title"); ?>
<?php $__env->startSection('meta_description',"$category->meta_description"); ?>
<?php $__env->startSection('meta_keyword',"$category->meta_keyword"); ?>
<?php $__env->startSection('content'); ?>

<div class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-9">
                    <div class="category-heading"><?php echo e($category->name); ?><div class="underline"></div></div>
                    <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="card card-shadow mt-4">
                        <!-- <div class="card-header"></div> -->
                        <div class="card-body">
                        <a href="<?php echo e(url('learn/'.$category->slug.'/'. $post->slug)); ?>">  
                             <h2 class="post-heading"><?php echo e($post->name); ?> </h2>
                        </a>
                        <h6>Posted On: <?php echo e($post->created_at->format('d-m-Y')); ?>, Created By: <?php echo e($post->user->name); ?></h6>
                        <div class="post-heading"></div>
                        <div class="underline"></div></div>
                       
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="card card-shadow mt-4">
                        <!-- <div class="card-header"></div> -->
                        <div class="card-body">
                            <h1>No Post Found</h1>                            
                        </div>
                    </div>

                    <?php endif; ?>
                    <div class="pagination mt-4">
                            <?php echo e($posts->links()); ?>

                    </div>
                    
                </div>
                
                <div class="right_part_separater col-md-3">
                    <div class="card">
                            <div class="sidebar-block-title">
                                <h4 class="widget-title">Categories</h4>
                            </div>
                            <div class="mt-0">
                            <?php $__currentLoopData = $all_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($item->posts_count > 0): ?>
                            <div class="category-box"> 
                            <a class="text-decoration-none" href="<?php echo e(url('learn/'.$item->slug)); ?>"><?php echo e($item->name); ?> (<?php echo e($item->posts_count); ?>)</a></div>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                    </div>
                    <div class="card">
                            <div class="sidebar-block-title">
                                <h4  class="widget-title">Latest Posts</h4>
                            </div>
                            <ul class="mt-4">
                            <?php $__currentLoopData = $latest_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>                               
                                <a class="text-decoration-none" href="<?php echo e(url('learn/'.$item->category->slug.'/'.$item->slug)); ?>"><img src="<?php echo e(asset('uploads/post/'.$item->image)); ?>" width="100" height="70" ></a>
                                <a class="sidebar-post-title  text-decoration-none" href="<?php echo e(url('learn/'.$item->category->slug.'/'.$item->slug)); ?>"><?php echo e($item->name); ?> <span class="post-time">Posted On: <?php echo e($item->created_at->format('d-m-Y')); ?>, Created By: <?php echo e($item->user->name); ?></span></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                    </div>
</div>
                
            </div>
        </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\omappblog\resources\views/frontend/post/index.blade.php ENDPATH**/ ?>