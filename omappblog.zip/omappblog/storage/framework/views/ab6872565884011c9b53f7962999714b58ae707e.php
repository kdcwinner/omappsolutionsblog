
<?php $__env->startSection('title','Edit Post'); ?>
<?php $__env->startSection('content'); ?>

<div class="container-fluid px-4">
                        
                        
                        <div class="card mt-4">
                            <div class="card-header">
                            <h4 class="">Post</h4>
                            <a href="<?php echo e(url('admin/posts')); ?>" class="btn btn-danger float-end">Back</a>
                            </div>
                            <div class="card-body">

                                <?php if($errors->any()): ?>
                                <div class="alert alert-dangour">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="alert alert-danger"><?php echo e($error); ?></div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <?php endif; ?>
                                <form action="<?php echo e(url('admin/update-post/'.$post->id)); ?>" method="POST" enctype="multipart/form-data">

                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="mb-3">
                                        <label for="">Category:</label>
                                       <select name="category_id" class="form-control">
                                                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($item->id); ?>" <?php echo e($item->id == $post->category_id ? 'selected' : ''); ?>><?php echo e($item->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                </div>
                                <div class="mb-3">
                                        <label for="">Title:</label>
                                        <input type="text" name="name" value="<?php echo e($post->name); ?> " class="form-control">
                                </div>
                                <div class="mb-3">
                                        <label for="">Slug:</label>
                                        <input type="text" name="slug" value="<?php echo e($post->slug); ?> "  class="form-control">
                                </div>
                                <div class="mb-3">
                                        <label for="">Description:</label>
                                        <textarea class="form-control description_summernote" name="description" rows="5"><?php echo e($post->description); ?>  </textarea>
                                </div>
                                <div class="mb-3">
                                        <label for="">Image:</label>
                                        <input type="file" name="image" class="form-control">
                                </div>
                                <div class="mb-3">
                                        <label for="">YouTube Ifrome:</label>
                                        <input type="text" name="yt_iframe" class="form-control" value="<?php echo e($post->yt_iframe); ?>" >
                                </div>
                                <div class="mb-3">
                                        <label for="">Related Posts:</label>
                                        <select name="related_post[]" multiple class="form-control select2_data">
                                                <?php $__currentLoopData = $all_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($item->id); ?>"  <?php if(in_array($item->id,explode(",",$post->related_post)) ): ?> selected <?php endif; ?>  ><?php echo e($item->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                </div>
                                <h6>SEO Tags</h6>
                                <div class="mb-3">
                                        <label for="">Meta Title:</label>
                                        <input type="text" name="meta_title" value="<?php echo e($post->meta_title); ?> "  class="form-control">
                                </div>
                                <div class="mb-3">
                                        <label for="">Meta Description:</label>
                                        <textarea class="form-control" name="meta_description" rows="5"><?php echo e($post->meta_description); ?></textarea>
                                </div>
                                <div class="mb-3">
                                        <label for="">Meta Keyword:</label>
                                        <input type="text" name="meta_keyword"  value="<?php echo e($post->meta_keyword); ?> " class="form-control">
                                </div>
                                <h6>Status Mode</h6>
                                <div class="row">                                
                                
                                    <div class="col-md-3 mb-3">
                                            <label for="">Status:</label>
                                            <input type="checkbox" name="status" <?php echo e($post->status == 1 ? 'checked' : ''); ?>>
                                    </div>
                                    <div class="col-md-6">
                                        <button type="submit" class="btn btn-primary">Update</button>
                                        <a href="<?php echo e(url('admin/posts')); ?>" class="btn btn-primary">Cancel</a>
                                    </div>
                                </div>
</form>
                                
                            </div>

                        </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\omappblog\resources\views/admin/post/edit.blade.php ENDPATH**/ ?>