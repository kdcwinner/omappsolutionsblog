@extends('layouts.master')
@section('title','Create User')
@section('content')

<div class="container-fluid px-4">
                        <div class="card mt-4">
                            <div class="card-header">
                            <h4 class="">Users</h4>
                            <a href="{{ url('admin/users') }}" class="btn btn-danger float-end">Back</a>
                            </div>
                            <div class="card-body">
                                @if($errors->any())
                                <div class="alert alert-dangour">
                                    @foreach($errors->all() as $error)
                                    <div class="alert alert-danger">{{ $error }}</div>
                                    @endforeach
                                </div>
                                @endif
                                <form action="{{ url('admin/add-user')}}" method="POST" enctype="multipart/form-data">

                                @csrf
                                <div class="mb-3">
                                        <label for="">Role:</label>
                                       <select name="role_as" class="form-control">                                                
                                                        <option value="1" {{ old("role_as") == 1 ? 'selected' : '' }}>Admin</option>
                                                        <option value="0" {{ old("role_as") == 0 ? 'selected' : '' }}>User</option>                                                
                                        </select>
                                </div>
                                <div class="mb-3">
                                        <label for="">Name:</label>
                                        <input type="text" name="name" value="{{ old('name')}}" class="form-control">
                                </div>
                                <div class="mb-3">
                                        <label for="">Email:</label>
                                        <input type="text" name="email" value="{{ old('email')}}" class="form-control">
                                </div>
                                <div class="mb-3">
                                        <label for="">Password:</label>
                                        <input type="password" name="password" value="{{ old('password')}}"  class="form-control">
                                </div>                                
                                <div class="row">                                    
                                    <div class="col-md-9">
                                        <button type="submit" class="btn btn-primary">Save</button>
                                    </div>
                                </div>
</form>
                                
                            </div>

                        </div>
</div>
@endsection