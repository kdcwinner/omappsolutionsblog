@extends('layouts.master')
@section('title','Create User')
@section('content')

<div class="container-fluid px-4">
                        <div class="card mt-4">
                            <div class="card-header">
                            <h4 class="">Users</h4>
                            <a href="{{ url('admin/users') }}" class="btn btn-danger float-end">Back</a>
                            </div>
                            <div class="card-body">
                                @if($errors->any())
                                <div class="alert alert-dangour">
                                    @foreach($errors->all() as $error)
                                    <div class="alert alert-danger">{{ $error }}</div>
                                    @endforeach
                                </div>
                                @endif
                                <form action="{{ url('admin/update-user/'.$user->id)}}" method="POST" enctype="multipart/form-data">

                                @csrf
                                @method('PUT')
                                <div class="mb-3">
                                        <label for="">Role:</label>
                                       <select name="role_as" class="form-control">                                                
                                                        <option value="1" {{ $user->role_as == 1 ? 'selected' : ''}}>Admin</option>
                                                        <option value="0" {{ $user->role_as == 0 ? 'selected' : ''}}>User</option>                                                
                                        </select>
                                </div>
                                <div class="mb-3">
                                        <label for="">Name:</label>
                                        <input type="text" name="name" value="{{  $user->name }}" class="form-control">
                                </div>
                                <div class="mb-3">
                                        <label for="">Title:</label>
                                        <input type="text" name="email"  value="{{ $user->email }}" class="form-control">
                                </div>
                                
                                                                
                                <div class="row">                                    
                                    <div class="col-md-9">
                                        <button type="submit" class="btn btn-primary">Update</button>
                                    </div>
                                </div>
</form>
                                
                            </div>

                        </div>
</div>
@endsection