@extends('layouts.master')
@section('title','User Listing')
@section('content')

<div class="container-fluid px-4"><div class="card">

    <div class="card-header">
        <h4>User List
        <a href="{{ url('admin/add-user') }}" class="btn btn-primary btn-sm float-end">Add User</a>
        </h4>
    </div>
    <div class="card-body">
        @if(session('message'))
            <div class="alert alert-success"> {{ session('message') }}</div>
            @endif

            <table  id="records_datatable" class="table table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($user as $item)
                    <tr>
                        <td>{{ $item->id }}</td>
                        <td>{{ $item->name }}</td>
                        <td>{{ $item->email }}</td>
                        <td> {{ $item->role_as == 1 ? 'Admin' : 'User'}} </td>                        
                        <td>
                            <a href="{{ $item->role_as == 1 ?'#': url('admin/edit-user/'.$item->id) }}" class="btn btn-primary">Edit </a>
                        </td>
                        <td>
                            <a href="{{ $item->role_as == 1 ?'#' : url('admin/delete-user/'.$item->id) }}"  onclick="return confirm('Are you sure you want to delete this item?');" class="btn btn-danger">Delete </a>
                        </td>                        
                    </tr>
                    @endforeach
                </tbody>
            </table>
    </div>
</div>
                        
</div>
@endsection