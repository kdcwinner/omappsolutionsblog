@extends('layouts.master')
@section('title','Category Listing')
@section('content')

<div class="container-fluid px-4"><div class="card">

    <div class="card-header">
        <h4>Category List
        <a href="{{ url('admin/add-category') }}" class="btn btn-primary btn-sm float-end">Add Category</a>
        </h4>
    </div>
    <div class="card-body">
        @if(session('message'))
            <div class="alert alert-success"> {{ session('message') }}</div>
            @endif

            <table id="records_datatable" class="table table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Status</th>
                        <th>Image</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($category as $item)
                    <tr>
                        <td>{{ $item->id }}</td>
                        <td>{{ $item->name }}</td>
                        <td> {{ $item->status == 1 ? 'Active' : 'Inactive'}} </td>
                        <td><image width="100" height="100" src="{{ asset('uploads/category/'.$item->image) }}" alt="{{$item->image}}" ></td>
                        <td>
                            <a href="{{ url('admin/edit-category/'.$item->id) }}" class="btn btn-primary">Edit </a>
                        </td>
                        <td>
                            <a href="{{ url('admin/delete-category/'.$item->id) }}"  onclick="return confirm('Are you sure you want to delete this item?');" class="btn btn-danger">Delete </a>
                        </td>
                        
                    </tr>
                    @endforeach
                </tbody>
            </table>
    </div>
</div>
                        
</div>
@endsection