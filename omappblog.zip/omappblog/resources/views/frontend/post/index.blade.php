@extends('layouts.app')
@section('title',"$category->meta_title")
@section('meta_description',"$category->meta_description")
@section('meta_keyword',"$category->meta_keyword")
@section('content')

<div class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-9">
                    <div class="category-heading">{{ $category->name }}<div class="underline"></div></div>
                    @forelse($posts as $post)
                    <div class="card card-shadow mt-4">
                        <!-- <div class="card-header"></div> -->
                        <div class="card-body">
                        <a href="{{ url('learn/'.$category->slug.'/'. $post->slug) }}">  
                             <h2 class="post-heading">{{ $post->name}} </h2>
                        </a>
                        <h6>Posted On: {{ $post->created_at->format('d-m-Y')}}, Created By: {{ $post->user->name }}</h6>
                        <div class="post-heading"></div>
                        <div class="underline"></div></div>
                       
                    </div>
                    @empty
                    <div class="card card-shadow mt-4">
                        <!-- <div class="card-header"></div> -->
                        <div class="card-body">
                            <h1>No Post Found</h1>                            
                        </div>
                    </div>

                    @endforelse
                    <div class="pagination mt-4">
                            {{ $posts->links() }}
                    </div>
                    
                </div>
                
                <div class="right_part_separater col-md-3">
                    <div class="card">
                            <div class="sidebar-block-title">
                                <h4 class="widget-title">Categories</h4>
                            </div>
                            <div class="mt-0">
                            @foreach($all_category as $item)
                            @if($item->posts_count > 0)
                            <div class="category-box"> 
                            <a class="text-decoration-none" href="{{url('learn/'.$item->slug) }}">{{ $item->name }} ({{ $item->posts_count }})</a></div>
                            @endif
                            @endforeach
                            </div>
                    </div>
                    <div class="card">
                            <div class="sidebar-block-title">
                                <h4  class="widget-title">Latest Posts</h4>
                            </div>
                            <ul class="mt-4">
                            @foreach($latest_posts as $item)
                            <li>                               
                                <a class="text-decoration-none" href="{{url('learn/'.$item->category->slug.'/'.$item->slug) }}"><img src="{{ asset('uploads/post/'.$item->image) }}" width="100" height="70" ></a>
                                <a class="sidebar-post-title  text-decoration-none" href="{{url('learn/'.$item->category->slug.'/'.$item->slug) }}">{{ $item->name }} <span class="post-time">Posted On: {{ $item->created_at->format('d-m-Y')}}, Created By: {{ $item->user->name }}</span></a></li>
                            @endforeach
                            </ul>
                    </div>
</div>
                
            </div>
        </div>
</div>
@endsection