@extends('layouts.app')
@section('title',"$post->meta_title")
@section('meta_description',"$post->meta_description")
@section('meta_keyword',"$post->meta_keyword")
@section('content')
        <div class="container">
            <div class="row">
                <div class="col-md-9 post-data">                                      
                    
                                                                       
                             <h2 class="post-heading">{!! $post->name !!} <label class=" float-end">{!! $shareButtons  !!}</label></h2>
                        <div class="underline"></div>
                        <img src="{{ asset('uploads/post/'.$post->image) }}" class="post-img" >

                        <div class="post-body">
                                {!! $post->description !!}
                        </div>
                    
                </div>
                <div class="right_part_separater col-md-3">
                    <div class="card">
                            <div class="sidebar-block-title">
                                <h4 class="widget-title">Categories</h4>
                            </div>
                            <div class="mt-4">
                            @foreach($all_category as $item)
                            <div class="category-box"> 
                            <a class="text-decoration-none" href="{{url('learn/'.$item->slug) }}">{{ $item->name }} ({{ $item->posts_count }})</a></div>
                            @endforeach
                            </div>
                    </div>
                    <div class="card">
                            <div class="sidebar-block-title">
                                <h4  class="widget-title">Latest Posts</h4>
                            </div>
                            <ul class="mt-4">
                            @foreach($latest_posts as $item)
                            <li>                               
                                <a class="text-decoration-none" href="{{url('learn/'.$item->category->slug.'/'.$item->slug) }}"><img src="{{ asset('uploads/post/'.$item->image) }}" width="100" height="70" ></a>
                                <a class="sidebar-post-title  text-decoration-none" href="{{url('learn/'.$item->category->slug.'/'.$item->slug) }}">{{ $item->name }} <span class="post-time">Posted On: {{ $item->created_at->format('d-m-Y')}}, Created By: {{ $item->user->name }}</span></a></li>
                            @endforeach
                            </ul>
                    </div>
                    @if(!empty($related_posts))
                    <div class="card">
                            <div class="sidebar-block-title">
                                <h4  class="widget-title">Related Posts</h4>
                            </div>
                            <ul class="mt-4">
                            @foreach($related_posts as $item)
                            <li><a class="text-decoration-none" href="{{url('learn/'.$item->category->slug.'/'.$item->slug) }}"><img src="{{ asset('uploads/post/'.$item->image) }}" width="100" height="70" ></a> 
                                <a class="sidebar-post-title text-decoration-none" href="{{url('learn/'.$item->category->slug.'/'.$item->slug) }}">{{ $item->name }}</a></li>
                            @endforeach
                            </ul>
                    </div>
                    @endif
                </div>
            </div>
        </div>

@endsection