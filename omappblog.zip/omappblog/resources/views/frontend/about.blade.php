@extends('layouts.app')
@section('title',"Om App Solutions")
@section('meta_description',"Om App Solutions is one of the best web development company in India")
@section('meta_keyword',"Om App Solutions, Web Application Development, Mobile Application Development")
@section('content')
<div class=" my-5" >
    <div class="container">
        <div class="row">
                <div class="col-md-12">
                    <h1>About</h1>
                    <div class="underline"></div>
                    <p>I, Ketan Chavda, a professional web developer having 9+ years of experience in PHP technology. Several years of experience in wide range of technologies focusing on web apps development. Full stack developer producing high quality responsive websites and web applications with strong backend support.I am a positive thinker.</p>
                    <p>Worked on different frameworks of PHP such as Symfony3,Cakephp3,CodeIgniter3,YII1.1 along with framework,worked on CMS such as Drupal8 and Joomla3,also worked on Angularjs1.1 and Angularjs8 too.Worked on different domains such as E-commerce,Education,CRM System,Lead Management System,Social Networking Websites etc.</p>
                </div>
        </div>
    </div>
</div>
@endsection