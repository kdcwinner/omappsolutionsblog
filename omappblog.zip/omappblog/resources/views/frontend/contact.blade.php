@extends('layouts.app')
@section('title',"Om App Solutions")
@section('meta_description',"Om App Solutions is one of the best web development company in India")
@section('meta_keyword',"Om App Solutions, Web Application Development, Mobile Application Development")
@section('content')
<div class=" my-5" >
    <div class="container">
        <div class="row">
                <div class="col-md-12">
                    <h1>Contact Us</h1>
                    <div class="underline"></div>
                    <div class="col-md-8">
                    @if($errors->any())
                        @foreach($errors->all() as $error)
                        <div class="alert alert-danger">{{ $error }}</div>
                        @endforeach
                    @endif
                    @if(session('message'))
            <div class="alert alert-success"> {{ session('message') }}</div>
            @endif
                    <h3>Leave me a message</h3>
                    <form name="sentMessage" id="contactForm" method="POST" action="{{url('add-contact')}}" novalidate="">
                       
                    @csrf
                    <div class="col-md-4">
                            <div class="form-group">
                            <input type="text" id="name" name="name" value="{{ old('name') }}" class="form-control" placeholder="Name" required="required" maxlength="40" data-validation-required-name="Please enter your name." aria-invalid="false">
                            <p class="help-block text-danger"></p></div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                            <input type="email" id="email" name="email" value="{{ old('email') }}" class="form-control" placeholder="Email" required="required" maxlength="40" data-validation-required-message="Please enter your email address.">
                            <p class="help-block text-danger"></p></div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                            <input type="text" id="contact" name="contact" value="{{ old('contact') }}" class="form-control" placeholder="Contact Number" maxlength="10"  required="required" data-validation-required-message="Please enter your contact number.">
                            <p class="help-block text-danger"></p></div>
                        </div>
                        </div>
                        <div class="form-group">
                        <textarea name="message" id="message" class="form-control" rows="8" placeholder="Message" required="" data-validation-required-message="Please enter message.">{{ old('message') }}</textarea>
                        <p class="help-block text-danger"></p></div>
                        <div id="success"></div>
                        <button type="submit" class="btn btn-site">Send Message</button>
                    </form>                    
                    </div>
                </div>
        </div>
    </div>
</div>
@endsection