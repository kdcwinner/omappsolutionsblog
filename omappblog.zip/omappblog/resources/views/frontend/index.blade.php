@extends('layouts.app')
@section('title',"Om App Solutions")
@section('meta_description',"Om App Solutions is one of the best web development company in India")
@section('meta_keyword',"Om App Solutions, Web Application Development, Mobile Application Development")


@section('content')
<div class="bg-danger my-5" style="display:none">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="owl-carousel category-carousel owl-theme">
                    @foreach($all_category as $item)
                    <div class="item">
                        <a class="text-decoration-none" href="{{url('learn/'.$item->slug) }}">
                            <div class="card">
                                <img src="{{ asset('uploads/category/'.$item->image)}}" alt="{{ $item->name }}">
                                <div class="card-body text-center">
                                    <h5>{{ $item->name }}</h5>
                                </div>
                            </div>
                        </a>
                    </div>
                    @endforeach
                </div>
            </div>
        </div>
    </div>
</div>
<div class="bg-gray">
    <div class="container">
        <div class="border text-center p-3">
            <h3>Advertising</h3>
        </div>
    </div>
</div>


<div class=" my-5">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="underline"></div>
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishi</p>
            </div>
        </div>
    </div>
</div>

<div class="my-5">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2>All Categories</h2>
                <div class="underline"></div>
            </div>
            @foreach($all_category as $item)
            <div class="col-md-3">
                <div class=" category-line-box shadow mb-3">
                <a class="va-top text-decoration-none" href="{{url('learn/'.$item->slug) }}"><img src="{{ asset('uploads/category/'.$item->image) }}" width="100" height="70" ></a>

                    <a href="{{ url('learn/'.$item->slug)}}"> {{$item->name}}</a>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</div>

<div class="my-5">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2>Latest Post</h2>
                <div class="underline"></div>
            </div>
            
                    @foreach($latest_posts as $item)
                    <div class="col-md-3">
                    <div class=" post-line-box shadow mb-3">
                     <a class="text-decoration-none" href="{{url('learn/'.$item->category->slug.'/'.$item->slug) }}"><img src="{{ asset('uploads/post/'.$item->image) }}" width="100" height="70" ></a>
                        <a href="{{ url('learn/'.$item->category->slug.'/'.$item->slug)}}" class="va-top"> {{ $item->name }}</a>
                        <br /><span class="post-time">Posted On: {{ $item->created_at->format('d-m-Y')}}, Created By: {{ $item->user->name }}</span>
                    </div>
                    
                    </div>
                    
                    @endforeach
             
            </div>
        </div>
    </div>
</div>
</div>


@endsection