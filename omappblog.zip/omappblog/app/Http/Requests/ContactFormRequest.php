<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ContactFormRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {

        $rules = [
            'name'=>['required','string','max:200','min:3'],
            'email'=>['required','email','max:255'],            
            'contact'=>['required','min:10','numeric'],
            'message'=>['required','min:3'],
        ];
        return  $rules;
    }
}
