<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class PostFormRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {

        $rules = [
            'category_id'=>['required'],
            'name'=>['required','string','max:200','min:3'],
            'slug'=>['required','string','max:255','min:3'],
            'description'=>['required','min:3'],
            'image'=>['nullable','mimes:jpeg,jpg,png,webp'],
            'yt_iframe'=>['nullable'],
            'related_post'=>['nullable'],
            'meta_title'=>['required','string','max:255'],
            'meta_description'=>['required'],
            'meta_keyword'=>['required'],
            'status'=>['nullable'],
        ];
        return  $rules;
    }
}
