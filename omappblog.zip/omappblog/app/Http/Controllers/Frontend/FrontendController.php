<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Post;
use App\Models\Category;
use App\Models\Contact;
use App\Models\Newsletter;
use App\Http\Requests\ContactFormRequest;
use App\Http\Requests\NewsletterFormRequest;

class FrontendController extends Controller
{
    public function index(){
        $all_category = $this->getAllCategory();
        $latest_posts = $this->getAllLatestPost('',7);
        return view('frontend.index',compact('all_category','latest_posts'));
    }

    public function about(){
        return view('frontend.about');
    }

    public function contact(){
        return view('frontend.contact');
    }

    public function storeContact(ContactFormRequest $request){
        
        $data = $request->validated();
        $contact = new Contact();       
        $contact->name = $data['name'];               
        $contact->email = $data['email'];
        $contact->contact = $data['contact'];
        $contact->message = $data['message'];
        $contact->save();
        return redirect('/contact')->with('message','Thank you for contacting us, our team will contact you soon!');
    }

    public function storeNewletter(NewsletterFormRequest $request){
        
        $data = $request->validated();
        if(Newsletter::where('email',$data['email'])->first()){
            return response()->json(['message'=>'You are already subscribed!','status'=>'already'],200);
        }
        $newsletter = new Newsletter();               
        $newsletter->email = $data['email'];
        $newsletter->save();
        return response()->json(['message'=>'Subscribe successfully!','status'=>'success'],200);

    }

    

    public function categoryWisePost(string $category_slug){
        $all_category = $this->getAllCategorWithPostCount();
        $latest_posts = $this->getAllLatestPost();     
        $category = Category::where('slug',$category_slug)->where('status',1)->first();
        $posts = [];
        if($category){
            $posts = Post::where('category_id',$category->id)->where('status',1)->orderBy('id','desc')->paginate(10);
            return view('frontend.post.index',compact('category','posts','all_category','latest_posts'));
        }else{
            return redirect('/');
        }
    }

    public function getAllCategory(string $slug=''){
        if($slug==''){
            $all_category = Category::where('status',1)->orderBy('id','desc')->get();
        }else{
            $all_category = Category::where('slug',$slug)->where('status',1)->first();
        }
        return $all_category;        
    }

    public function getAllCategorWithPostCount(string $slug=''){
        $all_category = Category::withCount('posts')->get();
        return $all_category;        
    }

    


    public function getAllLatestPost(string $slug='',$take_no_record='10'){
        if($slug==''){
            $all_post = Post::where('status',1)->orderBy('id','desc')->get()->take($take_no_record);
           
        }else{
            $all_post = Post::where('slug',$slug)->where('status',1)->first();
        }
        
        return $all_post;        
    }

    public function relatedPosts($related_post = ''){
        $related_posts = [];
        if($related_post!=''){
            $related_post = explode(",",$related_post);
            
            $related_posts = Post::whereIn('id',$related_post)->orderBy('id','desc')->get();
            
        }
        return $related_posts;        
    }    

    public function postDetail(string $category_slug,string $post_slug){
        $all_category = $this->getAllCategorWithPostCount();
        $category = Category::where('slug',$category_slug)->where('status',1)->first();
        $posts = [];
        if($category){
            
            $post = Post::where('category_id',$category->id)->where('slug',$post_slug)->where('status',1)->first();     
            $latest_posts = $this->getAllLatestPost();            
            $related_posts = $this->relatedPosts($post->related_post);
            if($post){            
                $shareButtons = \Share::page(
                    url('learn/'.$category_slug.'/'.$post->slug)
              )
              ->facebook()
              ->twitter()
              ->linkedin()
              ->telegram()
              ->whatsapp() 
              ->reddit();
                return view('frontend.post.details',compact('post','all_category','latest_posts','related_posts','shareButtons'));
            }else{
                return redirect('/');
            }
        }else{
            return redirect('/');
        }        
    }

    public function shares(){
        $shareButtons1 = \Share::page(
            url('learn/php')
      )
      ->facebook()
      ->twitter()
      ->linkedin()
      ->telegram()
      ->whatsapp() 
      ->reddit();

      // Share button 2
      $shareButtons2 = \Share::page(
        url('learn/php')
      )
      ->facebook()
      ->twitter()
      ->linkedin()
      ->telegram();

      // Share button 3
      $shareButtons3 = \Share::page(
        url('learn/php')
      )
      ->facebook()
      ->twitter()
      ->linkedin()
      ->telegram()
      ->whatsapp() 
      ->reddit();

      

      // Load index view
      return view('frontend.post.shares')
            ->with('shareButtons1',$shareButtons1 )
            ->with('shareButtons2',$shareButtons2 )
            ->with('shareButtons3',$shareButtons3 );
    }

    

}
