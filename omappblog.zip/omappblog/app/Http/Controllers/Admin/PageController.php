<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Category;
use App\Models\Post;
use App\Http\Requests\Admin\PostFormRequest;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Str;

class PageController extends Controller
{
    public function index(Request $request){
        $page = Page::all();
        return view('admin.page.index',compact('page'));
    }

    public function create(Request $request){
        
        return view('admin.page.create');
    }

    public function store(PageFormRequest $request){
        
        $data = $request->validated();
        $page = new Page();
        $page->category_id = $data['category_id'];
        $page->name = $data['name'];
        $page->slug = Str::slug($data['slug']);
        $page->description = $data['description'];
        $page->yt_iframe = $data['yt_iframe'];        
        $page->meta_title = $data['meta_title'];
        $page->meta_description = $data['meta_description'];
        $page->meta_keyword = $data['meta_keyword'];
        $page->status = $request->status == true ? '1': '0' ;
        $page->created_by = Auth::user()->id;
        $page->save();
        return redirect('admin/pages')->with('message','Page added successfully!');
    }

    public function edit($id){
        $page = Page::find($id);
        return view('admin.page.edit',compact('page'));
    }


    public function update(PageFormRequest $request,$id){
        
        $data = $request->validated();
        $page = Page::find($id);
        $page->name = $data['name'];
        $page->slug = Str::slug($data['slug']);
        $page->description = $data['description'];    
        $page->meta_title = $data['meta_title'];
        $page->meta_description = $data['meta_description'];
        $page->meta_keyword = $data['meta_keyword'];
        $page->status = $request->status == true ? '1': '0' ;
        $page->created_by = Auth::user()->id;
        $page->update();
        return redirect('admin/pages')->with('message','Page updated successfully!');
    }

    public function distroy($id){
        $page = Page::find($id);
        if($page){       
        $page->delete();
        return redirect('admin/pages')->with('message','Page Deleted successfully!');
        }else{
            return redirect('admin/pages')->with('message','No Page Found!');
        }
    }

}
