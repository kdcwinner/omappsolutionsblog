<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Contact;
use Illuminate\Support\Facades\Auth;

class ContactController extends Controller
{
    public function index(Request $request){
        $contacts = Contact::all();
        return view('admin.contact.index',compact('contacts'));
    }

    public function distroy($id){
        $contact = Contact::find($id);
        if($contact){       
        $contact->delete();
        return redirect('admin/contacts')->with('message','Contact Deleted successfully!');
        }else{
            return redirect('admin/contacts')->with('message','No Contact Found!');
        }
    }

}
