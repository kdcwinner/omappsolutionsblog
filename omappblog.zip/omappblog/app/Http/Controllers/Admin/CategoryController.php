<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Category;
use App\Http\Requests\Admin\CategoryFormRequest;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Str;

class CategoryController extends Controller
{
    public function index(Request $request){
        $category = Category::all();
        return view('admin.category.index',compact('category'));
    }

    public function create(Request $request){
        return view('admin.category.create');
    }

    public function store(CategoryFormRequest $request){
        
        $data = $request->validated();
        $category = new Category();
        $category->name = $data['name'];
        $category->slug = Str::slug($data['slug']);
        $category->description = $data['description'];
        if($request->hasfile('image')){
            $file = $request->file('image');
            $file_name = time().'.'.$file->getClientOriginalExtension();
            $file->move('uploads/category/',$file_name);
            $category->image = $file_name;
        }
        $category->meta_title = $data['meta_title'];
        $category->meta_description = $data['meta_description'];
        $category->meta_keyword = $data['meta_keyword'];
        $category->navebar_status = $request->navebar_status == true ? '1': '0' ;
        $category->status = $request->status == true ? '1': '0' ;
        $category->created_by = Auth::user()->id;
        $category->save();
        return redirect('admin/category')->with('message','Category added successfully!');
    }


    public function edit($id){
        $category = Category::find($id);
        return view('admin.category.edit',compact('category'));
    }


    public function update(CategoryFormRequest $request,$id){
        
        $data = $request->validated();
        $category = Category::find($id);
        $category->name = $data['name'];
        $category->slug = Str::slug($data['slug']);
        $category->description = $data['description'];
        if($request->hasfile('image')){
            $destination = 'uploads/category/'.$category->image;
            if(File::exists($destination)){
                File::delete($destination);
            }
            $file = $request->file('image');
            $file_name = time().'.'.$file->getClientOriginalExtension();
            $file->move('uploads/category/',$file_name);
            $category->image = $file_name;
        }
        $category->meta_title = $data['meta_title'];
        $category->meta_description = $data['meta_description'];
        $category->meta_keyword = $data['meta_keyword'];
        $category->navebar_status = $request->navebar_status == true ? '1': '0' ;
        $category->status = $request->status == true ? '1': '0' ;
        $category->created_by = Auth::user()->id;
        $category->update();
        return redirect('admin/category')->with('message','Category updated successfully!');
    }

    public function distroy($id){
        $category = Category::find($id);
        if($category){
            $destination = 'uploads/category/'.$category->image;
            if(File::exists($destination)){
                File::delete($destination);
            }           
       
        $category->delete();
        return redirect('admin/category')->with('message','Category Deleted successfully!');
        }else{
            return redirect('admin/category')->with('message','No Category Found!');
        }
    }

    
}
