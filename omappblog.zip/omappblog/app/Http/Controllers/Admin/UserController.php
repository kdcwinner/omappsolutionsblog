<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests\Admin\UserFormRequest;
use App\Models\User;
use Hash;

class UserController extends Controller
{
    public function index(Request $request){
        $user = User::all();
        return view('admin.user.index',compact('user'));
    }

    public function create(Request $request){        
        return view('admin.user.create');
    }

    public function store(UserFormRequest $request){
        
        $data = $request->validated();
        $user = new User();
        $user->role_as = $data['role_as'];
        $user->email = $data['email'];
        $user->name = $data['name'];
        $user->password = bcrypt($data['password']);      
        $user->save();
        return redirect('admin/users')->with('message','User added successfully!');
    }

    public function edit($id){
        $user = User::find($id);
        return view('admin.user.edit',compact('user'));
    }

    public function update(UserFormRequest $request,$id){
        
        $data = $request->validated();
        $user = User::find($id);
        $user->role_as = $data['role_as'];
        $user->email = $data['email'];
        $user->name = $data['name'];
        //$user->password = bcrypt($data['password']);        
        $user->update();
        return redirect('admin/users')->with('message','User updated successfully!');
    }

    public function distroy($id){
        $user = User::find($id);
        if($user){       
        $user->delete();
        return redirect('admin/users')->with('message','User Deleted successfully!');
        }else{
            return redirect('admin/users')->with('message','No User Found!');
        }
    }

}
